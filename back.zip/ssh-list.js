import fs from 'fs';

export const ssh_list = [
    {//티키타카
        host: '211.45.175.153',
        port: 22, // 기본 포트는 22번입니다.
        username: 'root',
        dns: 'tikitaka.kr',
        key_type: 'password',
        password: 'qjfwk100djr!',
    },
    {//럭스
        host: '54.79.149.16',
        port: 22, // 기본 포트는 22번입니다.
        username: 'ubuntu',
        privateKey: fs.readFileSync('C:/Users/pc/Desktop/project/virtual-account/keypair/lux/lux-pay.pem'),
        dns: 'lux-pay.com',
        key_type: 'pem',
    },
    {//나우
        host: '52.65.141.209',
        port: 22, // 기본 포트는 22번입니다.
        username: 'ubuntu',
        privateKey: fs.readFileSync('C:/Users/pc/Desktop/project/virtual-account/keypair/now-mall/now.pem'),
        dns: 'va.now-mall.com',
        key_type: 'pem',
    },
    {//마루
        host: '54.252.21.217',
        port: 22, // 기본 포트는 22번입니다.
        username: 'ubuntu',
        privateKey: fs.readFileSync('C:/Users/pc/Desktop/project/virtual-account/keypair/maru/maru.pem'),
        dns: 'ponyo-11.com',
        key_type: 'pem',
    },
    {//마이너스
        host: '3.104.6.73',
        port: 22, // 기본 포트는 22번입니다.
        username: 'ubuntu',
        privateKey: fs.readFileSync('C:/Users/pc/Desktop/project/virtual-account/keypair/minus/minus.pem'),
        dns: 'emerypay.com',
        key_type: 'pem',
    },
    {//트레이드
        host: '18.219.207.193',
        port: 22, // 기본 포트는 22번입니다.
        username: 'ubuntu',
        privateKey: fs.readFileSync('C:/Users/pc/Desktop/project/virtual-account/keypair/trade/tradecp10.pem'),
        dns: 'jnjtradecp10.com',
        key_type: 'pem',
    },
    {//플러스
        host: '18.116.18.32',
        port: 22, // 기본 포트는 22번입니다.
        username: 'ubuntu',
        privateKey: fs.readFileSync('C:/Users/pc/Desktop/project/virtual-account/keypair/plus/plus.pem'),
        dns: 'skymail.co.kr',
        key_type: 'pem',
    },
    {//KEI 홀린
        host: '3.133.218.23',
        port: 22, // 기본 포트는 22번입니다.
        username: 'ubuntu',
        privateKey: fs.readFileSync('C:/Users/pc/Desktop/project/virtual-account/keypair/kei/kei.pem'),
        dns: 'choi-114.com',
        key_type: 'pem',
    },
    {//K
        host: '3.12.114.115',
        port: 22, // 기본 포트는 22번입니다.
        username: 'ubuntu',
        privateKey: fs.readFileSync('C:/Users/pc/Desktop/project/virtual-account/keypair/kk/kk.pem'),
        dns: 'dl-7979.com',
        key_type: 'pem',
    },
    {//청룡
        host: '3.21.111.106',
        port: 22, // 기본 포트는 22번입니다.
        username: 'ubuntu',
        privateKey: fs.readFileSync('C:/Users/pc/Desktop/project/virtual-account/keypair/chungryong/chungryong.pem'),
        dns: 'bdbd-98.com',
        key_type: 'pem',
    },
]