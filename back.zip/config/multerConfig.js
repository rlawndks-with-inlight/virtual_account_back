import multer from 'multer';
import sharp from 'sharp';
import { checkDns, checkLevel } from '../utils.js/util.js';
import path from 'path';
import { fileURLToPath } from 'url';
import { returnMoment } from '../utils.js/function.js';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
import fs from 'fs';

const storage = multer.diskStorage({
        destination: function (req, file, cb) {
                let destination = __dirname + `/../files/${file.fieldname.split('_file')[0]}/`;
                let full_destination = `${destination}${returnMoment().slice(0, 10).replaceAll(' ', '').replaceAll('-', '')}/`;
                let is_exist_destination = fs.existsSync(destination);
                if (!is_exist_destination) {
                        fs.mkdirSync(destination);
                }
                let is_exist_full_destination = fs.existsSync(full_destination);
                if (!is_exist_full_destination) {
                        fs.mkdirSync(full_destination);
                }
                cb(null, `${full_destination}`);
        },
        filename: function (req, file, cb) {
                const decode_user = checkLevel(req.cookies.token, 0);
                const decode_dns = checkDns(req.cookies.dns);
                let user_id = "";
                if (decode_user) {
                        user_id = `${decode_user?.id}`;
                }
                let file_type = "";
                if (file.mimetype.includes('pdf')) {
                        file_type = 'pdf';
                } else {
                        file_type = 'jpeg';
                }
                cb(null, Date.now() + user_id + `-${file.fieldname.split('_file')[0]}${decode_dns?.id}.` + file_type)
        }
})
const fileFilter = (req, file, cb) => {
        let typeArray = file.mimetype.split('/')
        let filetype = typeArray[1]
        if (
                filetype == 'jpg' ||
                filetype == 'png' ||
                filetype == 'gif' ||
                filetype == 'jpeg' ||
                filetype == 'bmp' ||
                filetype == 'mp4' ||
                filetype == 'avi' ||
                filetype == 'webp' ||
                filetype == 'ico' ||
                filetype == 'pdf' ||
                filetype == 'svg' ||
                filetype == 'svg+xml' ||
                filetype == 'haansoftpdf'
        )
                return cb(null, true)

        console.log('확장자 제한: ', filetype)
        req.fileValidationError = "파일 형식이 올바르지 않습니다(.jpg, .png, .gif 만 가능)"
        cb(null, false, new Error("파일 형식이 올바르지 않습니다(.jpg, .png, .gif 만 가능)"))
}
const upload = multer({
        storage: storage,
        fileFilter: fileFilter,
        limit: {
                fileSize: 100 * 1024 * 1024,
                fieldSize: 100 * 1024 * 1024
        }
});

export default upload